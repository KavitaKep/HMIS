import java.awt.*;       // Import all classes from java.awt, java.awt.event,
import java.awt.event.*; // javax.swing, and java.util packages.
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.*;

import javax.swing.*;


public class HMISInterface extends JFrame {

   private Registry registry;
   private HomeQueue homeQueue;
   private CardLayout cardLayout;
   private JPanel cards;
   private JPanel homeQueuePanel;
   private Person user;
   private String userHash;
   private HMISWindowAdapter windowAdapter;

   
   HMISInterface(Registry registry, HomeQueue homeQueue) {
      super("SRHMIS Portal");
      this.registry = registry;
      this.homeQueue = homeQueue;
          

      this.windowAdapter = new HMISWindowAdapter(this, registry, homeQueue);
      addWindowListener(windowAdapter);


      JPanel firstScreenPanel = createFirstScreenPanel();
      JPanel surveyScreenPanel = createSurveyScreenPanel();


      this.cardLayout = new CardLayout();
      this.cards = new JPanel(cardLayout);

      cards.add(firstScreenPanel, "firstScreen");
      cards.add(surveyScreenPanel, "surveyScreen");


      add(cards);
   
      // Configure size and visibility.
      setSize(600, 250);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
   
   } // End of constructor.  

   private JPanel createFirstScreenPanel() {
      JLabel greeting = new JLabel("Welcome to the Sacramento Regional Homeless Management Information System");
      JLabel prompt1 = new JLabel("Enter your first name:");
      JLabel prompt2 = new JLabel("Enter your last name:");
      JLabel prompt3 = new JLabel("Enter the last four digits of your social security number:");
      JLabel Button = new JLabel("Invalid -- please enter your information into the appropriate fields.");

      JTextField firstName = new JTextField(15);
      JTextField lastName = new JTextField(15);
      JTextField ssn = new JTextField(15);

      ImageIcon backgroundIcon = new ImageIcon("icon.png");
      Image backgroundImg;
      try {
         backgroundImg = ImageIO.read(new File("icon.png"));
      } catch (IOException e) {
         e.printStackTrace();
         return null;
      }
      JLabel backgroundLabel = new JLabel(backgroundIcon);

      backgroundLabel.setLayout(new GridBagLayout()  );




      JButton enterButton = new JButton("Enter");
      Button.setVisible(false);

      JPanel Greeting = new JPanel();
      Greeting.add(greeting);

      JPanel textFields = new JPanel();
      
      GroupLayout firstScreenLayout = new GroupLayout(textFields);
      textFields.setLayout(firstScreenLayout);
      
      firstScreenLayout.setAutoCreateGaps(true);
      firstScreenLayout.setAutoCreateContainerGaps(true);
      
      GroupLayout.SequentialGroup horizGroup = firstScreenLayout.createSequentialGroup();
      horizGroup.addGroup(firstScreenLayout.createParallelGroup().
         addComponent(prompt1).addComponent(prompt2).addComponent(prompt3));
      horizGroup.addGroup(firstScreenLayout.createParallelGroup().
         addComponent(firstName).addComponent(lastName).addComponent(ssn));
      firstScreenLayout.setHorizontalGroup(horizGroup);        
      
      GroupLayout.SequentialGroup vertGroup = firstScreenLayout.createSequentialGroup();
      vertGroup.addGroup(firstScreenLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(prompt1).addComponent(firstName));
      vertGroup.addGroup(firstScreenLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(prompt2).addComponent(lastName));
      vertGroup.addGroup(firstScreenLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(prompt3).addComponent(ssn));
      firstScreenLayout.setVerticalGroup(vertGroup);
      
      JPanel buttonPanel = new JPanel();
      buttonPanel.add(enterButton);
      buttonPanel.add(Button);

      JPanel firstScreenPanel = new JPanel(new GridBagLayout()) {
         @ Override
         protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImg, 0, 0, this);
         }
      };
      GridBagConstraints c = new GridBagConstraints();
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.fill = GridBagConstraints.HORIZONTAL;
      
      firstScreenPanel.add(Greeting, c);
      firstScreenPanel.add(textFields, c);
      firstScreenPanel.add(buttonPanel, c);

      this.pack();


      enterButton.addActionListener(e -> {
           String vFirstName = firstName.getText();
           String vLastName = lastName.getText();
           String vSsn = ssn.getText();
           // Ensure name and ssn information is entered into textfields.      
           if (vFirstName.isEmpty() || vLastName.isEmpty() || vSsn.isEmpty()) {
              Button.setVisible(true); // Prompt user to re-enter information.
              return;
           }
           if (vSsn.length() != 4 || vSsn.matches("[0-9]+") == false){
              Button.setVisible(true); // Prompt user to re-enter information.
              return;
           }

           this.user = new Person(vFirstName, vLastName, vSsn);
           this.userHash = user.getHash();

           this.homeQueuePanel = createHomeQueuePanel();
           cards.add(homeQueuePanel, "homeQueue");
           
           boolean isPersonInRegistry = registry.containsHash(user.getHash());

           // Add user to registry and housing queue if they are not in registry
           if (isPersonInRegistry == true) {
               Object[] existingData = registry.getData(userHash);
               user = new Person(existingData);
               cardLayout.show(cards, "homeQueue");

           } else {
               cardLayout.show(cards, "surveyScreen");       
           }
       });

      return firstScreenPanel;
   }

   // Create the second Parent Panel with three (yes,no,decline to say) check boxes for if they are disabled, pregnant, or a veteran
   // Along with entry box for age
   private JPanel createSurveyScreenPanel(){
      JLabel survey_Prompt = new JLabel("To help us better serve you, indicate which of the following that applies to you:");
      JLabel agePrompt = new JLabel("Enter your age:");
      JLabel veteranPrompt = new JLabel("Are you a veteran?");
      JLabel pregnantPrompt = new JLabel("Are you pregnant?");
      JLabel disabledPrompt = new JLabel("Do you have a disibility?:");
      JLabel Button = new JLabel("Invalid -- please enter your information into the appropriate fields.");

      JTextField age = new JTextField(15);
      JCheckBox veteran = new JCheckBox();
      JCheckBox pregnant = new JCheckBox();
      JCheckBox disabled = new JCheckBox();

      JButton enterButton = new JButton("Enter");
      Button.setVisible(false);

      JPanel surveyPrompt = new JPanel();
      JPanel surveyInfo = new JPanel();
      JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      
      GroupLayout surveyLayout = new GroupLayout(surveyInfo);
      surveyInfo.setLayout(surveyLayout);

      surveyLayout.setAutoCreateGaps(true);
      surveyLayout.setAutoCreateContainerGaps(true);
      
      GroupLayout.SequentialGroup horizGroup2 = surveyLayout.createSequentialGroup();
      horizGroup2.addGroup(surveyLayout.createParallelGroup().
         addComponent(agePrompt).addComponent(veteranPrompt).addComponent(pregnantPrompt).addComponent(disabledPrompt));
      horizGroup2.addGroup(surveyLayout.createParallelGroup().
         addComponent(age).addComponent(veteran).addComponent(pregnant).addComponent(disabled));
      surveyLayout.setHorizontalGroup(horizGroup2);
      
      GroupLayout.SequentialGroup vertGroup2 = surveyLayout.createSequentialGroup();
      vertGroup2.addGroup(surveyLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(agePrompt).addComponent(age));
      vertGroup2.addGroup(surveyLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(veteranPrompt).addComponent(veteran));
      vertGroup2.addGroup(surveyLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(pregnantPrompt).addComponent(pregnant));
      vertGroup2.addGroup(surveyLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).
         addComponent(disabledPrompt).addComponent(disabled));
      surveyLayout.setVerticalGroup(vertGroup2);   

      surveyPrompt.add(survey_Prompt);
      buttonPanel.add(enterButton);
      buttonPanel.add(Button);

      GridBagConstraints c = new GridBagConstraints();
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.fill = GridBagConstraints.HORIZONTAL;
      
      JPanel surveyScreenPanel = new JPanel(new GridBagLayout());
      surveyScreenPanel.add(surveyPrompt, c);
      surveyScreenPanel.add(surveyInfo, c);
      surveyScreenPanel.add(buttonPanel, c);

      enterButton.addActionListener(e -> {
           // All information that is added is stored in the registry, it's okay if anything is left blank, but the age must be numeric
           if (age.getText().matches("[0-9]+") == false){
              Button.setVisible(true); // Prompt user to re-enter information.
              return;
           }
           if (!age.getText().isEmpty()){
              String vAge = age.getText();
              user.setAge(vAge);
           }

            Boolean vVeteran = veteran.isSelected();
            Boolean vPregnant = pregnant.isSelected();
            Boolean vDisabled = disabled.isSelected();

            user.setIsVeteran(vVeteran);
            user.setIsPregnant(vPregnant);
            user.setIsDisabled(vDisabled);

            registry.addPerson(user);
            cardLayout.show(cards, "homeQueue");
      });
      

      return surveyScreenPanel;
   }

   //Create the Homequeue panel, if someone is already in the queue it displays their position, along with the option to remove themselves or exit the program
   // If they are not in the queue it displays their position and the option to add themselves to the queue or exit the program
   private JPanel createHomeQueuePanel(){
      JLabel homeQueueGreeting = new JLabel("Housing Waitlist:");
      JLabel queue_prompt = new JLabel("You are currently number " + homeQueue.findPosition(userHash) + " in the housing waitlist.");
      JLabel notInQueue = new JLabel("You are not currently in the housing waitlist.");
      JLabel buttonPrompt = new JLabel("What would you like to do next?");
      JLabel Button = new JLabel("Invalid -- please enter your information into the appropriate fields.");

      JButton joinButton = new JButton("Join Waitlist");
      JButton removeButton = new JButton("Leave Waitlist");
      JButton exitButton = new JButton("Exit");

      JPanel greetingPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      JPanel QueuePrompt = new JPanel();
      JPanel buttonPromptPanel = new JPanel();
      JPanel ButtonPanel = new JPanel();

      if (homeQueue.contains(userHash)) {
         QueuePrompt.add(queue_prompt);
      } else {
         QueuePrompt.add(notInQueue);
      }
   
      buttonPromptPanel.add(buttonPrompt);
      ButtonPanel.add(joinButton);
      ButtonPanel.add(removeButton);
      ButtonPanel.add(exitButton);
      ButtonPanel.add(Button);
      Button.setVisible(false);

      GridBagConstraints c = new GridBagConstraints();
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.fill = GridBagConstraints.VERTICAL;
      
      JPanel homeQueuePanel = new JPanel(new GridBagLayout());
      homeQueuePanel.add(homeQueueGreeting, c);
      homeQueuePanel.add(QueuePrompt, c);
      homeQueuePanel.add(buttonPromptPanel, c);
      homeQueuePanel.add(ButtonPanel, c);
      
      joinButton.addActionListener(e -> {

         if(user.getIsVeteran()){
            homeQueue.addVeteran(userHash);
         } else {
            homeQueue.add(userHash);
         }

         // Remove the old label from QueuePrompt
         QueuePrompt.removeAll();
     
         queue_prompt.setText("You are currently number " + homeQueue.findPosition(userHash) + " in the housing waitlist.");
         // Add the new label to QueuePrompt
         if (homeQueue.contains(userHash)) {
             QueuePrompt.add(queue_prompt);
         } else {
             QueuePrompt.add(notInQueue);
         }
     
         // Redraw the panel
         QueuePrompt.revalidate();
         QueuePrompt.repaint();
     
         cardLayout.show(cards, "homeQueue");
       });

      removeButton.addActionListener(e -> {
         // Remove user from housing queue
         homeQueue.remove(userHash);

         QueuePrompt.removeAll();

         queue_prompt.setText("You are currently number " + homeQueue.findPosition(userHash) + " in the housing waitlist.");

         QueuePrompt.add(notInQueue);

         QueuePrompt.revalidate();
         QueuePrompt.repaint();

         cardLayout.show(cards, "homeQueue");
       });

      exitButton.addActionListener(e -> {
         // Exit the application
         WindowEvent windowClosing = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
         windowAdapter.windowClosing(windowClosing);  
         dispose();  
       });

      return homeQueuePanel;
   }

} // End of class HMISInterface.

class HMISWindowAdapter extends WindowAdapter {
    String housingQueuepath = "homeQueue.csv";
    String registryPath = "registry.csv";    
    JFrame window = null;
    Registry registry = null;
    HomeQueue homeQueue = null;
    
    HMISWindowAdapter(JFrame window, Registry registry, HomeQueue homeQueue) {
        this.window = window;
        this.registry = registry;
        this.homeQueue = homeQueue;
    }
            
    public void windowClosing(WindowEvent e) {
       // Write data to file when the window is closed
       registry.writeToFile(registryPath);
       homeQueue.writeToFile();
       
       // Exit the application
       System.exit(0);
   }
}
