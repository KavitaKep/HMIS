import java.io.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class HomeQueue {
    private LinkedList<String> housingQueue;
    private Map<String, Boolean> vetMap;  // Map to store boolean values corresponding to string values
    private String filepath;

    public HomeQueue(String filepath){
  
        this.housingQueue = new LinkedList<>();
        this.vetMap = new HashMap<>();
        this.filepath = filepath;
        loadFromFile();
    }

    public synchronized void add(String hash){
        housingQueue.addLast(hash);
        vetMap.put(hash, false);  // Store the boolean value in the map
    }


    public synchronized void addVeteran(String hash){
        int position = findVeteranInsertPosition();
        housingQueue.add(position, hash);
        vetMap.put(hash, true);  // Store the boolean value in the map
    }



    public synchronized void remove(String hash){   
        housingQueue.remove(hash);
        vetMap.remove(hash);  // Remove the boolean value from the map
    }

    private void loadFromFile(){
        try (BufferedReader reader = new BufferedReader(new FileReader(this.filepath))) {
            String line;

            while ((line = reader.readLine()) != null){
                String[] data = line.split(",");

                if (data.length >= 2){ // Ensuring that there are at least two elements in the array
                    String hash = data[0].trim();
                    boolean vet = Boolean.parseBoolean(data[1].trim()); 

                    if (vet){
                        addVeteran(hash);
                    } else {
                        add(hash);
                    }
                    vetMap.put(hash, vet);
                } 
                else{
                    // Handle the case where the line doesn't contain enough elements
                    System.err.println("Invalid line format: " + line);
                }
            }
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public void clearFile(){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.filepath))) {
            // Writing an empty string to the file effectively clears its content
            writer.write("");
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    
    public void writeToFile(){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(this.filepath))) {
            while (!housingQueue.isEmpty()) {
                String nextHash = housingQueue.poll();
                Boolean vetValue = vetMap.get(nextHash);

                if (nextHash != null && vetValue != null) {
                    writer.write(nextHash + "," + vetValue);
                    writer.newLine();
                }
            }
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    // Write a method that finds the next available priority position for a veteran. That means it checks if there is a segment of size 20 that contains
    // less than 5 veterans, insert them into that segment
    public int findVeteranInsertPosition(){
        int SEGMENTSIZE = 20;
        int VETQOUTA = 5;
        int vetCounter = 0;
        int i = 0;

        while(i < housingQueue.size()){
            if(vetMap.get(housingQueue.get(i)) == true){
                vetCounter++;
            }
            if(i != 0 && i % SEGMENTSIZE == 0){
                if(vetCounter < VETQOUTA){
                    if( i - SEGMENTSIZE < 0){
                        return vetCounter;
                    }
                    else{
                        return i - SEGMENTSIZE + vetCounter;
                    }
                }
                vetCounter = 0;
            }
            i++;
        }
        return i;
    }

    public int findPosition(String targetHash){
        return housingQueue.indexOf(targetHash) + 1;
    }

    public boolean contains(String targetHash){
        return housingQueue.contains(targetHash);
    }
}