import java.util.Random;

public class HMIS {
    public static void main(String[] args) throws Exception {
        String housingQueuepath = "homeQueue.csv";
        String registryPath = "registry.csv";
        Registry registry = new Registry(registryPath); 
        HomeQueue housingQueue = new HomeQueue(housingQueuepath);

        HMISInterface h1 = new HMISInterface(registry, housingQueue);
        h1.setVisible(true);

        
    }


    public static void generateData(int n, Registry registry, HomeQueue housinQueue){
        Random rand = new Random();
        for (int i = 0; i < n; i++){
            String firstName = "First" + i;
            String lastName = "Last" + i;
            String ssn = "123" + (i % 10);

            double pregProb = rand.nextDouble();
            double disProb = rand.nextDouble();
            double ageProb = rand.nextGaussian();
            double waitlistProb = rand.nextDouble();
            double vetProb = rand.nextDouble();
            int age = (int) (ageProb * 10) + 30;
            boolean isPreg;
            boolean isDis;
            boolean isVet;
            String ageStr = Integer.toString(age);
            boolean waitlist;
            
            if(pregProb > 0.002){
                isPreg = false;
            } else {
                isPreg = true;
            }

            if(disProb > 0.37){
                isDis = false;
            } else {
                isDis = true;
            }

            if (vetProb > .08){
                isVet = false;
            } else {
                isVet = true;
            }

            if (waitlistProb > .04){
                waitlist = false;
            } else {
                waitlist = true;
            }

            Person p = new Person(firstName, lastName, ssn);
            p.setIsVeteran(isVet);
            p.setIsPregnant(isPreg);
            p.setIsDisabled(isDis);
            p.setAge(ageStr);
            registry.addPerson(p);
            if(p.getIsVeteran() && waitlist){
                housinQueue.addVeteran(p.getHash());
            }
            else if (waitlist){
                housinQueue.add(p.getHash());
            }
        }
    }



}

